﻿using Microsoft.AspNetCore.Mvc;

namespace Last_Hope_Dating.Controllers
{
    public class Matched : Controller
    {
        public IActionResult MatchedView()
        {
            return View();
        }
    }
}
