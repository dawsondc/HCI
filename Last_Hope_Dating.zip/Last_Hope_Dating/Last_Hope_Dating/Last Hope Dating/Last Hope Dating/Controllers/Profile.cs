﻿using Microsoft.AspNetCore.Mvc;

namespace Last_Hope_Dating.Controllers
{
    public class Views : Controller
    {
        public IActionResult Profile()
        {
            return View();
        }
    }
}
